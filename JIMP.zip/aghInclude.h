#ifndef AGH_INCLUDE
#define AGH_INCLUDE

#include <iostream>
#include <string>
#include <cstdarg>

using namespace std;

#include "aghException.h"
#include "aghMatrix.h"
#include "aghComplex.h"

#endif
